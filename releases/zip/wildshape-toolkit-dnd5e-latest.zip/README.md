
# Wildshape-Toolkit

![Foundry VTT](https://img.shields.io/badge/Foundry%20VTT-13%20Stable-brightgreen)
![D&D 5e](https://img.shields.io/badge/D%26D%205e-5.2.4-blue)
![Compatibility](https://img.shields.io/badge/Compatibility-Foundry%2013-success)
![License](https://img.shields.io/github/license/AgentGGNik007/Wildshape-Toolkit)
![Version](https://img.shields.io/badge/dynamic/text?label=version&query=%24&cacheSeconds=0&url=https%3A%2F%2Fraw.githubusercontent.com%2FAgentGGNik007%2Fwildshape-toolkit-dnd5e%2FHEAD%2Fdata%2Fversion.txt)



Wildshape Toolkit (5e) is a full-featured Wild Shape module for Foundry VTT v13 (D&amp;D 5e v5.2.4). It provides a dedicated UI, system-native transformations, and ready-to-use SRD/homebrew Wild Shape forms with predefined stats, tokens, and effects for a smooth Wild Shape workflow.
